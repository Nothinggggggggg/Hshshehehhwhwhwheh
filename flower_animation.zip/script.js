
document.addEventListener('DOMContentLoaded', function () {
    let flowers = document.getElementsByClassName('flower');

    for (let i = 0; i < flowers.length; i++) {
        let flower = flowers[i];
        let delay = Math.random() * 2; // Random delay for each flower
        flower.style.animationDelay = `${delay}s`;
    }
});
